# Invoice Parser: Smart Document Processing System

Invoice Parser is a modular end-to-end system for processing business documents (invoices and POs) using a local-first MERN-style architecture.

## 🚀 Features

- **Multi-Format Support**: Handles PDF, Images, CSV, and TXT files.
- **Node.js + Express Backend**: Clean, modular architecture (Controllers, Services, Routes).
- **AI Extraction**: Uses Google's Gemini-3-Flash via REST API for OCR and structured extraction.
- **Robust Validation**: In-house validation engine for arithmetic, date, and field completeness checks.
- **In-Memory Storage**: Simple, local-first persistence (easily extensible to MongoDB).

## 🛠 Architecture

### Backend Structure

- `/backend/controllers`: Request handling and orchestrating services.
- `/backend/services`: Core logic including the `DocumentProcessor`.
- `/backend/services/parsers`: File-type specific extraction logic.
- `/backend/services/validators`: Business logic for document integrity.
- `/backend/routes`: API endpoint definitions.

### Frontend

- React 19 + Chakra UI v3.
- Minimal state management using standard React hooks.
- REST API integration for all document actions.

## 📋 Approach

1.  **Intelligent Ingestion**: The system uses `multer` for secure file uploads.
2.  **Modular Processing**: Files are passed to a `DocumentProcessor` that handles extraction and validation.
3.  **Strict Validation**: Extracted data is validated for mathematical integrity, duplicate document numbers, and date logic.
4.  **Review Loop**: Documents with warnings are flagged for manual review in the React interface.
