import { GoogleGenAI, Type } from "@google/genai";
import { ExtractedData } from "../../models/documentTypes";

let aiInstance: GoogleGenAI | null = null;

function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    console.log("API KEY:", apiKey);
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error(
        "GEMINI_API_KEY is missing or invalid in your .env file.",
      );
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export class GeminiParser {
  static async extractData(
    fileBuffer: Buffer,
    mimeType: string,
    fileName: string,
  ): Promise<ExtractedData> {
    const ai = getAI();
    const isText =
      mimeType === "text/plain" ||
      mimeType === "text/csv" ||
      fileName.endsWith(".csv") ||
      fileName.endsWith(".txt");

    const contents: any[] = [];

    if (isText) {
      contents.push({
        text: `DATA CONTENT OF ${fileName}:\n${fileBuffer.toString("utf-8")}`,
      });
    } else {
      contents.push({
        inlineData: {
          data: fileBuffer.toString("base64"),
          mimeType:
            mimeType === "application/pdf" ? "application/pdf" : mimeType,
        },
      });
    }

    contents.push({
      text: `Extract structured data from the document provided. 
      Return ONLY valid JSON matching the specified schema. 
      If a value is missing, use null or appropriate default. 
      Document is likely an invoice or purchase order.`,
    });

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            documentType: {
              type: Type.STRING,
              enum: ["invoice", "purchase_order"],
            },
            supplierName: { type: Type.STRING },
            documentNumber: { type: Type.STRING },
            issueDate: {
              type: Type.STRING,
              description: "ISO date format YYYY-MM-DD",
            },
            dueDate: {
              type: Type.STRING,
              description: "ISO date format YYYY-MM-DD",
            },
            currency: { type: Type.STRING },
            lineItems: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  description: { type: Type.STRING },
                  quantity: { type: Type.NUMBER },
                  unitPrice: { type: Type.NUMBER },
                  amount: { type: Type.NUMBER },
                },
                required: ["description", "quantity", "unitPrice", "amount"],
              },
            },
            subtotal: { type: Type.NUMBER },
            tax: { type: Type.NUMBER },
            total: { type: Type.NUMBER },
          },
          required: [
            "documentType",
            "supplierName",
            "documentNumber",
            "issueDate",
            "currency",
            "lineItems",
            "subtotal",
            "tax",
            "total",
          ],
        },
      },
    });

    const result = JSON.parse(response.text || "{}");
    return result as ExtractedData;
  }
}
