// This file defines data structures related to documents, including the extracted data format,
// validation issues, and the final processed document structure.
// It serves as a contract for how document data should be represented throughout the application.

interface LineItem {
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
}

interface ExtractedData {
  documentType: "invoice" | "purchase_order";
  supplierName: string;
  documentNumber: string;
  issueDate: string;
  dueDate?: string;
  currency: string;
  lineItems: LineItem[];
  subtotal: number;
  tax: number;
  total: number;
}

interface ValidationIssue {
  field: string;
  message: string;
  severity: "error" | "warning";
}

interface ProcessedDocument extends ExtractedData {
  id: string;
  status: "uploaded" | "needs_review" | "validated" | "rejected";
  validationIssues: ValidationIssue[];
  createdAt: string;
  fileName: string;
}

export type { LineItem, ExtractedData, ValidationIssue, ProcessedDocument };
